
document.querySelectorAll(".produto button").forEach(btn => {
    btn.addEventListener("click", () => alert("Produto adicionado ao carrinho!"));
});
